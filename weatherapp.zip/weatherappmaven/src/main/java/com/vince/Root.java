package com.vince;

import java.awt.Image.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import java.awt.*;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.text.*;

import org.json.JSONObject;

import net.bytebuddy.asm.Advice.Local;

public class Root extends JFrame {  

    private org.json.simple.JSONObject weatherData;

    public Root(){

        //Create main window
        /*JFrame root = new JFrame();
        setTitle("Weathr"); //title
        setSize(450, 650); //size in pixels

        setDefaultCloseOperation(EXIT_ON_CLOSE); //configures GUI to end the program once it's been closed

        root.setLocationRelativeTo(null); //loads GUI at the centre of the screen
        root.setResizable(false); //prevents any resizing of GUI
        root.setVisible(true);*/
        //Create data interface
        super("Weathr");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(450, 650);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
        setVisible(true);
        addGUIComponents();
    }

    private void addGUIComponents(){

        //Creates JLayeredPane to order JComponents Z order
        JLayeredPane layer = new JLayeredPane();
        layer.setPreferredSize(new Dimension(450, 650));
        setContentPane(layer);
        //layer.add(component logoLabel, 1);

        //Logo
        ImageIcon logoIcon = new ImageIcon(new ImageIcon("src\\main\\java\\com\\vince\\weathrlogo.png").getImage().getScaledInstance(90, 30, Image.SCALE_SMOOTH));
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setBounds(40, 90, 90, 30);
        logoLabel.setVisible(true);
        add(logoLabel);

        //City search text box
        JTextField searchTextField = new JTextField();
        searchTextField.setBounds(40,30, 300, 45); //sets size and position of TextField
        searchTextField.setFont(new Font("Dialog", Font.PLAIN, 24));
        searchTextField.setVisible(true);
        add(searchTextField);

        //Location text from "resolvedAddress" on JSON
        JLabel locationText = new JLabel("Fredericton, New Brunswick");
        locationText.setBounds(0, 150, 450, 54);
        locationText.setFont(new Font("Dialog", Font.BOLD, 20));
        locationText.setHorizontalAlignment(SwingConstants.CENTER);
        locationText.setVisible(true);
        locationText.setBackground(Color.BLACK);
        add(locationText);

        //Weather condition image
        JLabel weatherConditionImage = new JLabel(loadImage("src\\main\\java\\com\\vince\\assets\\cloudy.png"));
        weatherConditionImage.setBounds(0, 150, 450, 217);
        weatherConditionImage.setVisible(true);
        add(weatherConditionImage);

        //Temperature: "temperature_2m"
        JLabel temperatureText = new JLabel("°C");
        temperatureText.setBounds(0, 310, 450, 54);
        temperatureText.setFont(new Font("Dialog", Font.BOLD, 48));
        temperatureText.setHorizontalAlignment(SwingConstants.CENTER);
        temperatureText.setVisible(true);
        add(temperatureText);

        //Feels like: "apparent_temperature"
        JLabel feelsLikeText = new JLabel("Feels like" + "°C");
        feelsLikeText.setBounds(0, 360, 450, 54);
        feelsLikeText.setFont(new Font("Dialog", Font.BOLD, 20));
        feelsLikeText.setHorizontalAlignment(SwingConstants.CENTER);
        feelsLikeText.setVisible(true);
        add(feelsLikeText);

        //Creates description for weather condition //weathercode
        JLabel weatherConditionDesc = new JLabel("Cloudy ahh");
        weatherConditionDesc.setBounds(0, 415, 450, 36);
        weatherConditionDesc.setFont(new Font("Dialog", Font.PLAIN, 32));   
        weatherConditionDesc.setHorizontalAlignment(SwingConstants.CENTER);
        weatherConditionDesc.setVisible(true);
        add(weatherConditionDesc);

        //Air quality from "quality" from "CAFC" or "CYFC" //Air quality from air quality index
        JLabel airQualityText = new JLabel("<html><center><b>Air quality<b><center><html>" + 10);
        airQualityText.setBounds(25, 480, 85, 55);
        airQualityText.setFont(new Font("Dialog", Font.PLAIN, 16));
        add(airQualityText);

        //Wind speed from "windspeed"
        JLabel windText = new JLabel("<html><center><b>Wind<b><br><center><html>" + 10 + "km/h");
        windText.setBounds(110, 480, 85, 55);
        windText.setFont(new Font("Dialog", Font.PLAIN, 16));
        add(windText);

        //Humidity from "humidity"
        JLabel humidityText = new JLabel("<html><center><b>Humidity<b><center><html> 100%");
        humidityText.setBounds(180, 480, 85, 55);
        humidityText.setFont(new Font("Dialog", Font.PLAIN, 16));
        add(humidityText);      
        
        JLabel visibilityText = new JLabel("<html><center><b>Visibility<b><center><html>" + 10 + "km");
        visibilityText.setBounds(260, 480, 85, 55);
        visibilityText.setFont(new Font("Dialog", Font.PLAIN, 16));
        add(visibilityText);

        //UV Index
        JLabel UVIndexText = new JLabel("<html><center><b>UV Index<b><center><html>" + 10);
        UVIndexText.setBounds(335, 480, 85, 55);
        UVIndexText.setFont(new Font("Dialog", Font.PLAIN, 16));
        add(UVIndexText);

        //Creates main window as JPanel to customize
        JPanel mainPanel = new JPanel();
        Color background = Color.decode("#535C91");
        mainPanel.setBounds(0, 0, 450, 650);
        mainPanel.setBackground(background);
        mainPanel.setVisible(true);
        add(mainPanel);

        //Search button
        ImageIcon searchIcon = new ImageIcon(new ImageIcon("src\\main\\java\\com\\vince\\assets\\searchButton.png").getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH ));
        JButton searchButton = new JButton(searchIcon);
        searchButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //changes cursor to a hand cursor when hovering over the search button
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userInput = searchTextField.getText(); //gets location from user input
                
                if (userInput.replaceAll("\\s", "").length() <=0){ //removes whitespace 
                    return;
                }

                weatherData = WeatherApp.getWeatherData(userInput);

                String weatherCondition = (String) weatherData.get("weather_condition");
                String weatherConditionImagePath = (String) weatherData.get("weather_condition_image_path");

                switch(weatherCondition){
                    case weatherCondition:
                        weatherConditionImage.setIcon(loadImage(weatherConditionImagePath));
                        break;
                }   

                double temperature = (double) weatherData.get("temperature");
                temperatureText.setText(temperature + "°C");

                weatherConditionDesc.setText(weatherCondition);

                long humidity = (long) weatherData.get("humidity");
                humidityText.setText("<html><center><b>Humidity<b><center><html>" + humidity + "%");

                double windSpeed = (double) weatherData.get("wind_speed");
                windText.setText("<html><center><b>Wind<b><br><center><html>" + windSpeed + "km/h");

                double visibility = (double) weatherData.get("visibility");
                visibilityText.setText("<html><center><b>Visibility<b><center><html>" + visibility + "km");\

                double UVIndex = (double) weatherData.get("uv_index");
                UVIndexText.setText("<html><center><b>UV Index<b><center><html>" + UVIndex);

            }
        
        });
        searchButton.setBounds(360, 30, 47, 45);
        searchButton.setVisible(true);
        add(searchButton);
        
        JPanel timePanel = new JPanel();

}       

    private ImageIcon loadImage(String resourcePath){
        try { 
            BufferedImage image = ImageIO.read(new File(resourcePath));

            return new ImageIcon(image);
        } catch (IOException e){
            e.printStackTrace();
        }

        System.out.println("Couldn't find resource.");
        return null;
    }
}
