package com.vince;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import javax.swing.SwingUtilities;

import org.apache.http.client.methods.HttpGet;

public class AppLauncher {
    public static void main(String[] args) throws Exception {

        SwingUtilities.invokeLater(new Runnable(){

            @Override

            public void run(){
                new Root(); //displays weather app GUI
                /*System.out.println(WeatherApp.getLocationData("Fredericton"));
                System.out.println(WeatherApp.getCurrentTime());
                System.out.println(WeatherApp.getWeatherData("Fredericton"));
                System.out.println(WeatherApp.convertWeatherCode(0, 0, null));*/
            }
        });

        /*HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/Fredericton?unitGroup=metric&include=days%2Ccurrent%2Calerts&key=DJ3QF7PFURMPZN66XCFPKE8GF&contentType=json"))
            .method("GET", HttpRequest.BodyPublishers.noBody()).build();

        HttpResponse<String> response = HttpClient.newHttpClient()
            .send(request, HttpResponse.BodyHandlers.ofString());
            
        System.out.println(response.body());*/

    }
}
