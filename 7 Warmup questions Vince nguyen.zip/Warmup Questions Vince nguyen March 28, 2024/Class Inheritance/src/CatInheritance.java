public class CatInheritance{
public static void main(String[] args) throws Exception {
    Cat salami = new Cat(4, "female", 80, "Salami", "John", "Siamese Cat"); 
    salami.makeSound();
    salami.purr();
    salami.hiss();

    if(salami instanceof Animal){
        System.out.println("Salami is an instance of Animal");
    }else{
        System.out.println("Salami is NOT an instance of Animal");
    }

    //We can access Animal's inner class too
    Animal.HumanOwners.innerClassMsg();
}
}