public class Dog extends Pet{
    public String breed; 
    
    public Dog(int ageIn, String sexIn, double weightIn, String nameIn, 
      String ownersNameIn, String breedIn){ 
        super(ageIn, sexIn, weightIn, nameIn, ownersNameIn); 
        this.breed = breedIn; 
    }
    
    //overriding parent method makeSound()
    public void makeSound(){
        System.out.println(this.name + " is barking! woof woof");
    }
    public void growl(){ 
        System.out.println(this.name + " is growling."); 
    } 
    public void chaseTail(){ 
        if(sex.equalsIgnoreCase("female")) 
            System.out.println(this.name + " is chasing her tail!"); 
        else 
            System.out.println(this.name + " is chasing his tail!"); 
    } 
}
