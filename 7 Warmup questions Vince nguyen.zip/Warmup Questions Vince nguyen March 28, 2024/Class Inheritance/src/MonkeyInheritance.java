public class MonkeyInheritance {

    public static void main(String[] args) throws Exception {
        Monkey bozo = new Monkey(5, "male", 120, "Bozo", "Bay of Fundy", "New Brunswick", "Baboon"); 
        bozo.makeSound();
        bozo.swingFromTree();
    
        if(bozo instanceof Animal){
            System.out.println("Bozo is an instance of Animal");
        }else{
            System.out.println("Bozo is NOT an instance of Animal");
        }
    
        //We can access Animal's inner class too
        Animal.HumanOwners.innerClassMsg();
}
}
