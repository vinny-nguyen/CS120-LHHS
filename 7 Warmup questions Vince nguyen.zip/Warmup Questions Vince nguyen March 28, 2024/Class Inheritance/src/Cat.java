public class Cat extends Pet{

    //COMPLETE THE CODE...
    //Add breed variable
    public String breed;
    public Cat (int ageIn, String sexIn, double weightIn, String nameIn, 
      String ownersNameIn, String breedIn){ 
        super(ageIn, sexIn, weightIn, nameIn, ownersNameIn); 
        this.breed = breedIn; 
    }

    public void makeSound(){
        System.out.println(this.name + " is meowing! Meow.");
    }
    public void purr(){
        System.out.println(this.name + " is purring. Purr purr.");
    }
    public void hiss(){ 
        System.out.println(this.name + " is hissing. Hiss hiss."); 
    } 
    //Add purr() method -> Returns "this.name " + " is purring"
    //Add hiss() method -> Returns "this.name " + " is hissing"

}
