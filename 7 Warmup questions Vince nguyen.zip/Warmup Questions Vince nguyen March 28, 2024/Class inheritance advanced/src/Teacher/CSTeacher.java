package Teacher;

public class CSTeacher extends TeacherClass {
    protected String subject = "programming";
    protected String language = "java";
    protected double raiseAmount = 1.10;
    public CSTeacher(String first_name, String last_name, String school){
        super(first_name, last_name, school);
    }
    public double applyRaise(double raiseAmount){
        return salary = salary + salary*raiseAmount;
    }
    public void writeCode(){
        System.out.println("Mr. " + this.last_name + "is writing code.");

    }
    public void drinkCoffee(){
        System.out.println("Mr. " + this.last_name + "is drinking coffee.");

    }
    
}
