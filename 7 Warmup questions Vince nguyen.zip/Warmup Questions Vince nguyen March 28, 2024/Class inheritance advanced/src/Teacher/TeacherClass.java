package Teacher;

public class TeacherClass {
    protected String first_name;
    protected String last_name;
    protected String school;
    protected double salary;
    protected double raiseAmount;

    public TeacherClass(String first_name, String last_name, String school){
        this.first_name = first_name;
        this.last_name = last_name;
        this.school = school;        
    }

    public double applyRaise(double raiseAmount){
        return salary = salary + salary*raiseAmount;
    }
}
