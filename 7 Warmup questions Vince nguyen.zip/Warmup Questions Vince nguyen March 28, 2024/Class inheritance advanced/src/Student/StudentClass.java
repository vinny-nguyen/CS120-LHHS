package Student;
public class StudentClass {

    //Instance Variables
    //private
    protected String first_name;
    protected String last_name;
    protected String fullname;
    protected String id;
    protected int age;    
    protected int grade;
    //public
    public int year;
    public String schoolName = "Leo Hayes High School";
    public boolean busStudent;
    
    //Class instance constructor
    public StudentClass(String first_name, String last_name, String id){
        this.first_name = first_name;
        this.last_name = last_name;
        this.id = id;        
    }

    //getter and setter methods
    public void setID(String id){
        this.id = id;
    }
    public String getID(){
        return id;
    }

    public void setAge(int age){
        this.age = age;
    }
    public int getAge(){
        return age;
    }

    public void setYear(int year){
        this.year = year;
    }
    public int getYear(){
        return year;
    }

    public void setGrade(int grade){
        this.grade = grade;
    }
    public int getGrade(){
        return grade;
    }

    public String getFullname(){
        fullname = first_name + " " + last_name;
        return fullname;
    }

    //class methods
    public String getEmail(){
        String email;
        email = String.format("%1$s.%2$s@nbss.nbed.nb.ca",first_name,last_name);
        return email;
    }
    
}
