package Student;

public class ScienceStudent extends StudentClass{
    //class attribute unique to ScienceStudent Class
    protected String favSubject;

    //ScienceStudent Class Constructor
    public ScienceStudent(String first_name, String last_name, String id){
        super(first_name, last_name, id);
    }

    public void setFavSub(String favSubject){
        this.favSubject = favSubject;
    }
    public String getFavSub(){
        return favSubject;
    }
}
