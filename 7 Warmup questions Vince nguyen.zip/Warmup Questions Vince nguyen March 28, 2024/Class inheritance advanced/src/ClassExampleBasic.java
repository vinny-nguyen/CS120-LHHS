import Student.StudentClass;
import Student.ScienceStudent;

public class ClassExampleBasic {
    public static void main(String[] args) throws Exception {

        //Creating an instance of the StudentClass
        StudentClass student1 = new StudentClass("Joe", "Smith", "102445");
        System.out.println("New Student Record Created!");

        //Initializing Instance variables with setter methods:
        student1.setAge(14);
        student1.setGrade(4);
        student1.setYear(11);
                
        //We now have access to other class variables and methods:
        System.out.printf("Student's Full Name: %s\n", student1.getFullname());
        System.out.printf("Student Email: %s\n", student1.getEmail().toLowerCase());        
        System.out.printf("Student School: %s\n", student1.schoolName);

        //Create an instance of ScienceStudent:
        ScienceStudent student2 = new ScienceStudent("Jennifer", "Knox", "103346");
        student2.setFavSub("Physics");
        System.out.printf("Student's Full Name: %s\n", student2.getFullname());
        System.out.printf("Student Email: %s\n", student2.getEmail().toLowerCase());
        System.out.printf("Student's Favorite Subject: %s\n", student2.getFavSub());
    }
}
