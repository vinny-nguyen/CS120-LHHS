public class InheritanceExample {
    public static void main(String[] args) throws Exception {

        //create an instance of Dog which inherits from 'Pet' and 'Animal' superclasses
        Dog sparky = new Dog(3, "male", 100, "Sparky", "Jill", "Labrador");        
        
        //call some methods from dog class and inherited methods
        sparky.makeSound();
        sparky.chaseTail();
        sparky.sleep();

        //Use the 'instanceof' operator to see if a class is a subclass of a parent
        if(sparky instanceof Animal){
            System.out.println("sparky is an instance of Animal");
        }else{
            System.out.println("sparky is NOT an instance of Animal");
        }

        //We can access Animal's inner class too
        Animal.HumanOwners.innerClassMsg(); 

    }
}
