public abstract class WildAnimal extends Animal{

    //COMPLETE THE CODE...
    public String habitatIn; 
    public String locationIn;

    public WildAnimal(int ageIn,
               String sexIn,
               double weightIn,
               String nameIn,
               String habitatIn, 
               String locationIn){
                 
        super(ageIn, sexIn, weightIn, nameIn);
        this.locationIn = locationIn;
        this.habitatIn = habitatIn;
    } 
    public void play(){ 
        System.out.println(name + " is playing."); 
    }
    //Add habitat variable
    //Add location variable
    //Add play() method -> Returns "this.name " + "is playing"
}
