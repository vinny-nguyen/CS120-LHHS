
//This is an 'abstract' class, it is not possible to instantiate it
public abstract class Animal {
    public int age;
    public String sex;
    public double weight;
    public String name;

    public Animal(int ageIn,
                  String sexIn,
                  double weightIn,
                  String nameIn){

        this.age = ageIn;
        this.sex = sexIn;
        this.weight = weightIn;
        this.name = nameIn;
    }

    //Here is an example of an inner class, it has access to the outer class's vars
    public static class HumanOwners{
        public static void innerClassMsg(){
            System.out.println("Hello from Animal's inner class!");
        }
    }

    //methods common to all subclasses
    public abstract void makeSound(); //This is an 'abstract' method, override in subclass    
    public void move(){
        System.out.println(this.name + " is moving!");
    }	
    public void eat(){
        System.out.println(this.name + " is eating!");
    }	
    public void sleep(){
        System.out.println(this.name + " is sleeping!");
    }	
    public void speak(){
        System.out.println(this.name + " is speaking!");
    }	
    public void cleanSelf(){
        System.out.println(this.name + " is grooming itself!");
    }
    public void purr(){
        System.out.println(this.name + " is purring");
    }
    public void hiss(){ 
        System.out.println(this.name + " is hissing");
    }
    public void grow(double growBy){
        this.weight += growBy;
    }	
    public void age(){
        this.age++;
    }
}
