public class Monkey extends WildAnimal {

    //COMPLETE THE CODE...
    public String breed;
    public Monkey (int ageIn, String sexIn, double weightIn, String nameIn, 
      String habitatIn, String locationIn, String breedIn){ 
        super(ageIn, sexIn, weightIn, nameIn, habitatIn, locationIn); 
        this.breed = breedIn; 
    }

    public void makeSound(){
        System.out.println(this.name + " is making sounds. Ooh ooh aah aah");
    }
    public void swingFromTree (){
        System.out.println(this.name + " is Swinging from a Tree. Weeeee.");
    }
    //Add type variable    
    //Add swingFromTree() method -> Returns "this.name " + "is swinging from a tree"
}
