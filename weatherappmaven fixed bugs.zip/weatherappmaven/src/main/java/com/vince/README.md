1. Create API keys from a service of interest (i.e. weather forecast, sports, scores)
a. Create user accounts
b. Get URL to request API data

2. Handle with Java HttpRequest: send 'request' get 'response' in the form of a json file
a. JSON (javescipt object notation) - a dictionary with key value pairs to get data

3. Coding
a. Create a project as a Maven build so we can import dependencies outside of the JDK API (built in libraries)
b.

